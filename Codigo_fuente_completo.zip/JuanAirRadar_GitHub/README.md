# Juan Air Radar — GitHub Pages + servicio de datos

Versión independiente de ChatGPT Work. El iPad muestra la web de GitHub Pages; un Worker de Cloudflare consulta las fuentes que no aceptan peticiones directas desde Safari (CORS). No necesita claves de ADS-B ni de METAR. Requiere una cuenta propia en GitHub y otra en Cloudflare. Los límites de uso de cada proveedor siguen aplicando.

## 1. Publicar el servicio

Opción sencilla: en Cloudflare Workers crear un Worker, abrir el editor y reemplazar su código por `worker/worker.js` (incluido y compilado). Añadir una variable de texto `ALLOWED_ORIGIN` con el origen de GitHub Pages: `https://juanola746.github.io` (sin la carpeta del repositorio). Publicar y copiar la URL HTTPS del Worker.

Alternativa desde terminal: `cd worker`, `npm install`, `npx wrangler login`, `npm run deploy`. El archivo wrangler.jsonc ya incluye ese origen.

## 2. Publicar la pantalla

Crear un repositorio `juan-air-radar` en tu cuenta GitHub y cargar el contenido de esta carpeta conservando `docs/` y `worker/`. En `docs/config.js`, pegar la URL real del Worker como apiBase. En Settings → Pages elegir Deploy from a branch → main → /docs y guardar. Abrir el enlace que indique GitHub Pages.

El Worker no se instala en GitHub Pages: este solo aloja archivos estáticos. Hasta configurar el Worker, el radar dirá CONFIGURAR FUENTE. También podés escribir su URL desde el engranaje de la app, pero ese ajuste queda únicamente en ese iPad.

## 3. Instalar en iPad

Abrir la dirección de GitHub Pages en Safari → Compartir → Agregar a pantalla de inicio. Nombre: Juan Air Radar. Usar horizontal. San Fernando es el centro predeterminado; el engranaje permite cambiarlo. La aplicación requiere internet y las fuentes pueden interrumpirse.

## Datos y estado

Tráfico: adsb.lol, con adsb.fi como respaldo (uso personal y atribución obligatoria). METAR: Aviation Weather Center / NOAA-NWS. Radar: RainViewer. Mapa: Esri. Aeródromos: OurAirports. Créditos en INFO / SOURCES.

Un fallo de API se muestra como FUENTE NO DISPONIBLE, no como pérdida de internet. Las fuentes alternan y los reintentos tienen espera progresiva. La máscara de RainViewer permite distinguir falta de cobertura de imagen sin ecos; esa máscara puede estar desactualizada. Las posiciones antiguas se retiran y los datos nunca se simulan.

Validado: compilación del Worker, sintaxis JavaScript, rutas relativas para repositorios y parámetros de origen. Pendiente: publicación en tus cuentas y prueba real desde el iPad.

Inspirado en un radar de escritorio; no es el programa propietario de Sporty’s ni un instrumento para navegación.
