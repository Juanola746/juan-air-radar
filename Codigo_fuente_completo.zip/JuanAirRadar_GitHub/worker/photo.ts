export async function GET(request:Request){
 const reg=new URL(request.url).searchParams.get("reg")||"";
 if(!/^[a-zA-Z0-9-]{2,12}$/.test(reg))return Response.json({error:"Matrícula inválida"},{status:400});
 try{
  const r=await fetch("https://api.planespotters.net/pub/photos/reg/"+encodeURIComponent(reg),{signal:AbortSignal.timeout(8000),headers:{"User-Agent":"JuanAirTraffic/1.0 (+https://juan-air-traffic-radar.solartang14.chatgpt.site)"}});
  if(!r.ok)throw new Error("photo");
  const d=await r.json() as {photos?:{thumbnail_large?:{src:string};thumbnail?:{src:string};photographer?:string;link?:string}[]};
  const p=d.photos?.[0],image=p?.thumbnail_large?.src||p?.thumbnail?.src;
  if(!image||!/^https:\/\/[^/]*planespotters\.net\//.test(image))return Response.json({photo:null});
  return Response.json({photo:image,photographer:p?.photographer||"Planespotters.net",link:p?.link&&/^https:\/\/www\.planespotters\.net\//.test(p.link)?p.link:"https://www.planespotters.net"});
 }catch{return Response.json({photo:null,error:"Foto no disponible"},{status:502});}
}
