import airportData from "../docs/radar/airports-ar.json";
type Item=Record<string,unknown>;
const cache=new Map<string,{until:number;data:unknown}>();
const num=(v:unknown)=>typeof v==="number"&&Number.isFinite(v)?v:null;
const text=(v:unknown,n=180)=>typeof v==="string"?v.replace(/[\x00-\x1f]/g,"").trim().slice(0,n):null;
function distance(a:number,b:number,c:number,d:number){
 const rad=Math.PI/180,h=Math.sin((c-a)*rad/2)**2+Math.cos(a*rad)*Math.cos(c*rad)*Math.sin((d-b)*rad/2)**2;
 return 3440.065*2*Math.atan2(Math.sqrt(h),Math.sqrt(Math.max(0,1-h)));
}
async function noaaReports(ids:string[]):Promise<Item[]>{
 const reports=await Promise.all(ids.slice(0,6).map(async id=>{
  try{
   const r=await fetch("https://tgftp.nws.noaa.gov/data/observations/metar/stations/"+id+".TXT",{signal:AbortSignal.timeout(8000)});
   if(!r.ok)return null;
   const body=await r.text(),timestamp=body.match(/(\d{4}\/\d{2}\/\d{2})\s+(\d{2}:\d{2})/);
   const raw=body.split(/\r?\n/).slice(1).join(" ").trim();
   if(!timestamp||!new RegExp("^(METAR |SPECI )?"+id+"\\b").test(raw))return null;
   const observed=Date.parse(timestamp[1].replaceAll("/","-")+"T"+timestamp[2]+":00Z")/1000;
   if(!Number.isFinite(observed))return null;
   const a=airportData.airports.find(a=>a.id===id);if(!a)return null;
   const wind=raw.match(/\b(\d{3}|VRB)(\d{2,3})(?:G(\d{2,3}))?(KT|MPS|KMH)\b/);
   const temp=raw.match(/(?:^|\s)(M?\d{2})\/(M?\d{2}|\/\/)(?=\s|$)/);
   const pressure=raw.match(/\bQ(\d{4})\b/),altimeter=raw.match(/\bA(\d{4})\b/);
   const factor=wind?.[4]==="MPS"?1.943844:wind?.[4]==="KMH"?.539957:1;
   const degrees=(v:string)=>v.startsWith("M")?-Number(v.slice(1)):Number(v);
   return {icaoId:id,name:a.name,lat:a.lat,lon:a.lon,obsTime:observed,
    wdir:wind?(wind[1]==="VRB"?"VRB":Number(wind[1])):null,
    wspd:wind?Math.round(Number(wind[2])*factor*10)/10:null,wgst:wind?.[3]?Math.round(Number(wind[3])*factor*10)/10:null,
    temp:temp?degrees(temp[1]):null,dewp:temp&&temp[2]!=="//"?degrees(temp[2]):null,
    altim:pressure?Number(pressure[1]):altimeter?Math.round(Number(altimeter[1])/100*33.86389):null,
    rawOb:raw,fltCat:null,cover:/\bCAVOK\b/.test(raw)?"CAVOK":null,provider:"NOAA / NWS"};
  }catch{return null;}
 }));
 return reports.filter((a):a is NonNullable<typeof a>=>a!==null);
}
export async function GET(request:Request){
 const q=new URL(request.url).searchParams,lat=Number(q.get("lat")??-34.455),lon=Number(q.get("lon")??-58.5913889);
 if(!Number.isFinite(lat)||!Number.isFinite(lon)||Math.abs(lat)>85||Math.abs(lon)>180||q.get("lat")===""||q.get("lon")==="")return Response.json({error:"Coordenadas inválidas"},{status:400});
 const key=lat.toFixed(3)+","+lon.toFixed(3),saved=cache.get(key);
 if(saved&&saved.until>Date.now())return Response.json(saved.data);
 try{
  const ids=airportData.airports.filter(a=>/^S[AU][A-Z0-9]{2}$/.test(a.id)).map(a=>({id:a.id,d:distance(lat,lon,a.lat,a.lon)})).filter(a=>a.d<100).sort((a,b)=>a.d-b.d).slice(0,12).map(a=>a.id);
  if(!ids.length)return Response.json({station:null});
  let rows:Item[]=[];let primaryFailed=false;
  try{
   const r=await fetch("https://aviationweather.gov/api/data/metar?ids="+encodeURIComponent(ids.join(","))+"&format=json",{headers:{"User-Agent":"JuanAirTraffic/1.0 (+https://juan-air-traffic-radar.solartang14.chatgpt.site)"},signal:AbortSignal.timeout(4000)});
   if(r.status!==204){if(!r.ok)throw new Error("METAR "+r.status);const body=await r.json();if(!Array.isArray(body))throw new Error("schema");rows=body;}
  }catch{primaryFailed=true;}
  if(!rows.length)rows=await noaaReports(ids);
  if(!rows.length&&primaryFailed)throw new Error("Official METAR sources unavailable");
  const latest=new Map<string,Item>();
  for(const a of rows){
   const id=text(a.icaoId,8);if(!id||num(a.lat)===null||num(a.lon)===null||num(a.obsTime)===null)continue;
   if(!latest.has(id)||(num(a.obsTime)??0)>(num(latest.get(id)?.obsTime)??0))latest.set(id,a);
  }
  const near=[...latest.values()].map(a=>({...a,distance:distance(lat,lon,num(a.lat)!,num(a.lon)!)})).filter(a=>a.distance<100).sort((a,b)=>a.distance-b.distance);
  const a=near[0] as (Item&{distance:number})|undefined;
  const data=a?{station:text(a.icaoId,8),name:text(a.name,120),distance:Math.round(a.distance*10)/10,observedAt:num(a.obsTime),
   windDirection:a.wdir==="VRB"?"VRB":num(a.wdir),windSpeed:num(a.wspd),windGust:num(a.wgst),
   temperature:num(a.temp),dewpoint:num(a.dewp),qnh:num(a.altim),visibility:text(String(a.visib??""),20),
   category:text(a.fltCat,12)||text(a.cover,12),cover:text(a.cover,20),raw:text(a.rawOb,700),source:text(a.provider,50)||"Aviation Weather Center"}:{station:null};
  if(cache.size>40)cache.clear();cache.set(key,{until:Date.now()+240000,data});
  return Response.json(data);
 }catch(error){console.warn("METAR failed",error instanceof Error?error.message:"unknown");return Response.json({error:"METAR no disponible"},{status:502});}
}
