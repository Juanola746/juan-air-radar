import {GET as traffic} from './traffic';
import {GET as weather} from './weather';
import {GET as conditions} from './conditions';
import {GET as photo} from './photo';
const routes:Record<string,(r:Request)=>Promise<Response>>={'/api/traffic':traffic,'/api/weather':weather,'/api/conditions':conditions,'/api/photo':photo};
export default {async fetch(request:Request,env:{ALLOWED_ORIGIN?:string}):Promise<Response>{
 const origin=request.headers.get('Origin');
 const allowed=env.ALLOWED_ORIGIN||'';
 const headers={'Access-Control-Allow-Origin':allowed,'Access-Control-Allow-Methods':'GET, OPTIONS','Vary':'Origin','Cache-Control':'no-store'};
 if(origin&&origin!==allowed)return new Response('Origin not allowed',{status:403});
 if(request.method==='OPTIONS')return new Response(null,{status:204,headers});
 if(request.method!=='GET')return new Response('Method not allowed',{status:405,headers});
 const handler=routes[new URL(request.url).pathname];if(!handler)return new Response('Not found',{status:404,headers});
 try{const r=await handler(request);const h=new Headers(r.headers);for(const [k,v] of Object.entries(headers))h.set(k,v);return new Response(r.body,{status:r.status,headers:h});}
 catch{return Response.json({error:'Fuente no disponible'},{status:502,headers});}
}};
