type Frame={path:string;time:number};
let cached:{until:number;frame:unknown}|null=null;
export async function GET(){
 if(cached&&cached.until>Date.now())return Response.json(cached.frame);
 try{
  const r=await fetch("https://api.rainviewer.com/public/weather-maps.json",{signal:AbortSignal.timeout(9000)});
  if(!r.ok)throw new Error("Weather source HTTP "+r.status);
  const d=await r.json() as {radar?:{past?:Frame[]}};
  const frames=(d.radar?.past||[]).filter(p=>/^\/v2\/radar\/[a-zA-Z0-9_-]{1,80}$/.test(p.path)&&Number.isFinite(p.time)&&p.time>0).sort((a,b)=>a.time-b.time).slice(-13);
  const p=frames.at(-1);
  if(!p)throw new Error("frame");
  const frame={host:"https://tilecache.rainviewer.com",path:p.path,time:p.time,frames};
  cached={until:Date.now()+120000,frame};return Response.json(frame);
 }catch(error){console.warn("Weather source failed",error instanceof Error?error.message:"unknown");return Response.json({error:"Radar meteorológico no disponible"},{status:502});}
}
