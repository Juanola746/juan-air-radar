type Item=Record<string,unknown>;
let primaryRetryAt=0;
const cache=new Map<string,{expires:number;data:unknown}>();
const text=(v:unknown,n=70)=>typeof v==="string"?v.replace(/[\x00-\x1f]/g,"").trim().slice(0,n):null;
const num=(v:unknown)=>typeof v==="number"&&Number.isFinite(v)?v:null;
export async function GET(request:Request){
 const q=new URL(request.url).searchParams;
 const lat=q.has("lat")?Number(q.get("lat")):-34.455,lon=q.has("lon")?Number(q.get("lon")):-58.5913889;
 if(!Number.isFinite(lat)||!Number.isFinite(lon)||Math.abs(lat)>85||Math.abs(lon)>180||q.get("lat")===""||q.get("lon")==="")return Response.json({error:"Coordenadas inválidas."},{status:400});
 const key=lat.toFixed(4)+"/"+lon.toFixed(4),old=cache.get(key);
 if(old&&old.expires>Date.now())return Response.json(old.data,{headers:{"Cache-Control":"private, no-store"}});
 try{
  let b:Item|null=null,source='adsb.lol';
  const providers=[{name:'adsb.lol',url:'https://api.adsb.lol/v2/point/'+key+'/50'}, {name:'adsb.fi',url:'https://opendata.adsb.fi/api/v3/lat/'+lat.toFixed(4)+'/lon/'+lon.toFixed(4)+'/dist/50'}];
  for(const provider of providers){
   if(provider.name==='adsb.lol'&&primaryRetryAt>Date.now())continue;
   try{
    const r=await fetch(provider.url,{signal:AbortSignal.timeout(4500),headers:{Accept:'application/json','User-Agent':'JuanAirRadar/1.0 (+https://juan-air-traffic-radar.solartang14.chatgpt.site)'}});
    if(!r.ok)throw new Error('HTTP '+r.status);
    const data=await r.json() as Item;if(!Array.isArray(data.ac))throw new Error('schema');b=data;source=provider.name;break;
   }catch(e){if(provider.name==='adsb.lol')primaryRetryAt=Date.now()+60000;console.warn('Traffic provider unavailable',provider.name,e instanceof Error?e.message:'unknown');}
  }
  if(!b||!Array.isArray(b.ac))throw new Error('No traffic source available');
  const aircraft=b.ac.filter((v):v is Item=>!!v&&typeof v==="object").slice(0,800).map(a=>({
   hex:text(a.hex,12),flight:text(a.flight,16),registration:text(a.r,16),type:text(a.t,12),
   lat:num(a.lat),lon:num(a.lon),altitude:a.alt_baro==="ground"?"ground":num(a.alt_baro),
   speed:num(a.gs),track:num(a.track),verticalSpeed:num(a.baro_rate),seen:num(a.seen_pos)??num(a.seen)??999,
   squawk:text(a.squawk,8),emergency:text(a.emergency,30),category:text(a.category,5),operator:text(a.ownOp),source:text(a.type,25)
  })).filter(a=>a.hex&&a.lat!==null&&a.lon!==null&&Math.abs(a.lat)<=90&&Math.abs(a.lon)<=180);
  const data={aircraft,receivedAt:Date.now(),feedTime:num(b.now),source,radius:50};
  if(cache.size>50)cache.clear();cache.set(key,{data,expires:Date.now()+1800});
  return Response.json(data,{headers:{"Cache-Control":"private, no-store"}});
 }catch(error){console.warn("Traffic source failed",error instanceof Error?error.message:"unknown");return Response.json({error:"La fuente de tráfico no está disponible. Reintentando…"},{status:502,headers:{"Cache-Control":"no-store"}});}
}
